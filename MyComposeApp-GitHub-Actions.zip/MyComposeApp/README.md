# MyComposeApp

Kotlin + Jetpack Compose Android project آماده برای GitHub Actions.

## گرفتن APK

1. کل محتوای این پوشه را داخل یک repository جدید GitHub آپلود کنید.
2. به تب **Actions** بروید.
3. workflow با نام **Build APK** را باز کنید.
4. با **Run workflow** اجرا کنید، یا یک commit/push انجام دهید.
5. بعد از اتمام build، در بخش **Artifacts** فایل `MyComposeApp-debug-apk` را دانلود کنید.

APK خروجی:
`output/MyComposeApp-debug.apk`

این APK نسخه Debug است و برای نصب و تست مناسب است. برای انتشار در Google Play باید release signing جداگانه تنظیم شود.
